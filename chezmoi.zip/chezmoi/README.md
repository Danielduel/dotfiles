TODO

move swaylock
move waybar
add slurp into wfrecorder to hyprland keybindings