pacman -S --needed git base-devel && git clone https://aur.archlinux.org/yay.git && cd yay && makepkg -si
/bin/bash -c "$(curl https://sh.rustup.rs -sSf)" -- -y
