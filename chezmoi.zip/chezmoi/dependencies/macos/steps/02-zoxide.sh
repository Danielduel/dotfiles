cargo install zoxide
